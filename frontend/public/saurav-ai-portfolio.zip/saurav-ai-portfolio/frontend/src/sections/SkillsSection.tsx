import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Activity,
  BarChart3,
  BrainCircuit,
  Cloud,
  Code2,
  Cpu,
  Database,
  Layers,
  Search,
  Server,
  Sparkles,
  Terminal,
  Wrench,
} from 'lucide-react';
import { Skill } from '../types/portfolio';
import { Tilt3DCard } from '../components/Tilt3DCard';
import { Section3DBackdrop } from '../components/Section3DBackdrop';

interface SkillsSectionProps {
  skills: Skill[];
}

const CATEGORIES = [
  'All',
  'Programming',
  'AI and Machine Learning',
  'Generative AI and Agentic AI',
  'Frameworks and Libraries',
  'Backend Development',
  'Databases',
  'Cloud and MLOps',
  'Analytics and Development Tools',
];

const getCategoryIcon = (category: string) => {
  switch (category) {
    case 'Programming':
      return Code2;
    case 'AI and Machine Learning':
      return BrainCircuit;
    case 'Generative AI and Agentic AI':
      return Sparkles;
    case 'Frameworks and Libraries':
      return Layers;
    case 'Backend Development':
      return Server;
    case 'Databases':
      return Database;
    case 'Cloud and MLOps':
      return Cloud;
    case 'Analytics and Development Tools':
      return BarChart3;
    default:
      return Cpu;
  }
};

export const SkillsSection: React.FC<SkillsSectionProps> = ({ skills }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredSkills = useMemo(() => {
    return skills.filter((skill) => {
      const matchesCat =
        selectedCategory === 'All' || skill.category === selectedCategory;
      const matchesSearch =
        !searchQuery.trim() ||
        skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        skill.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (skill.description &&
          skill.description.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCat && matchesSearch;
    });
  }, [skills, selectedCategory, searchQuery]);

  return (
    <section id="skills" className="relative py-24 overflow-hidden">
      <Section3DBackdrop variant="matrix" accent="purple" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/10 border border-violet-500/30 text-xs font-mono text-cyan-300 mb-3">
              <span>02 // TECHNICAL ARSENAL & STACK</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Categorized{' '}
              <span className="bg-gradient-to-r from-violet-400 to-cyan-300 bg-clip-text text-transparent">
                Engineering Capabilities
              </span>
            </h2>
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Python, LangGraph, SHAP..."
              aria-label="Search technical skills"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 focus:border-cyan-400/60 text-xs text-white placeholder:text-slate-500 focus:outline-none backdrop-blur-md"
            />
          </div>
        </div>

        {/* Interactive Category Filter Pills */}
        <div className="flex flex-wrap gap-2 mb-10">
          {CATEGORIES.map((category) => {
            const active = selectedCategory === category;
            const count =
              category === 'All'
                ? skills.length
                : skills.filter((s) => s.category === category).length;
            return (
              <button
                key={category}
                type="button"
                onClick={() => setSelectedCategory(category)}
                className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                  active
                    ? 'bg-gradient-to-r from-violet-600 to-cyan-600 text-white shadow-[0_0_20px_rgba(139,92,246,0.4)]'
                    : 'bg-white/[0.03] hover:bg-white/[0.07] border border-white/10 text-slate-300'
                }`}
              >
                <span>{category}</span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    active ? 'bg-black/30 text-cyan-200' : 'bg-white/5 text-slate-400'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* 3D Animated Skill Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredSkills.map((skill, idx) => {
            const Icon = getCategoryIcon(skill.category);
            return (
              <motion.div
                key={skill.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.25, delay: Math.min(idx * 0.015, 0.25) }}
              >
                <Tilt3DCard intensity={12} className="h-full rounded-2xl">
                  <div className="h-full rounded-2xl border border-white/10 hover:border-cyan-400/40 bg-[#080c19]/85 p-4 backdrop-blur-xl flex flex-col justify-between transition">
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2.5">
                        <div className="w-9 h-9 rounded-xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center">
                          <Icon className="w-4 h-4 text-cyan-300" />
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/[0.04] border border-white/10 text-slate-400">
                          {skill.category}
                        </span>
                      </div>
                      <h3 className="text-sm font-bold text-white mb-1">
                        {skill.name}
                      </h3>
                      {skill.description && (
                        <p className="text-xs text-slate-400 leading-relaxed">
                          {skill.description}
                        </p>
                      )}
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-cyan-300/80">
                      <span className="inline-flex items-center gap-1">
                        <Terminal className="w-3 h-3 text-violet-400" />
                        Verified Project Stack
                      </span>
                      <Activity className="w-3 h-3 text-emerald-400" />
                    </div>
                  </div>
                </Tilt3DCard>
              </motion.div>
            );
          })}
        </div>

        {filteredSkills.length === 0 && (
          <div className="text-center py-12 rounded-2xl border border-white/10 bg-white/[0.02]">
            <Wrench className="w-8 h-8 text-slate-500 mx-auto mb-2" />
            <p className="text-sm text-slate-300">
              No skills matched "{searchQuery}". Try clearing your filter.
            </p>
          </div>
        )}
      </div>
    </section>
  );
};
