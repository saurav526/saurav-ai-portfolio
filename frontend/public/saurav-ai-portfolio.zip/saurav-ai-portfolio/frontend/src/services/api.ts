import {
  FALLBACK_GITHUB_DATA,
  INITIAL_PORTFOLIO_DATA,
} from '../data/portfolioData';
import {
  ContactSubmissionItem,
  GitHubProfileData,
  PortfolioData,
  ProfileConfig,
  Project,
  Skill,
} from '../types/portfolio';

import { asset } from '../lib/asset';
const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';
const STORAGE_KEY = 'saurav_portfolio_state_v2';
const CONTACTS_STORAGE_KEY = 'saurav_portfolio_contacts_v2';

export function getLocalPortfolioState(): PortfolioData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw) as PortfolioData;
    }
  } catch {
    // ignore storage errors
  }
  return INITIAL_PORTFOLIO_DATA;
}

export function saveLocalPortfolioState(data: PortfolioData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    window.dispatchEvent(new CustomEvent('portfolio-data-updated', { detail: data }));
  } catch {
    // ignore storage errors
  }
}

export async function fetchPortfolioData(): Promise<PortfolioData> {
  try {
    const resp = await fetch(`${API_BASE}/portfolio`);
    if (resp.ok) {
      const data = (await resp.json()) as PortfolioData;
      saveLocalPortfolioState(data);
      return data;
    }
  } catch {
    // Backend offline; use local state
  }
  return getLocalPortfolioState();
}

export async function fetchGitHubProfile(): Promise<GitHubProfileData> {
  try {
    const resp = await fetch(`${API_BASE}/github/profile`);
    if (resp.ok) {
      return (await resp.json()) as GitHubProfileData;
    }
  } catch {
    // Try direct public GitHub API from browser if backend is offline
    try {
      const [uResp, rResp] = await Promise.all([
        fetch('https://api.github.com/users/saurav526'),
        fetch('https://api.github.com/users/saurav526/repos?sort=updated&per_page=12'),
      ]);
      if (uResp.ok && rResp.ok) {
        const u = await uResp.json();
        const repos = await rResp.json();
        const langMap: Record<string, number> = {};
        const formatted = (Array.isArray(repos) ? repos : [])
          .filter((r: Record<string, unknown>) => !r.fork)
          .map((r: Record<string, unknown>) => {
            const lang = (r.language as string) || 'Python';
            langMap[lang] = (langMap[lang] || 0) + 1;
            return {
              name: String(r.name || ''),
              html_url: String(r.html_url || ''),
              description:
                String(r.description || '') ||
                'AI, Machine Learning, and Data Science engineering repository.',
              language: lang,
              topics: Array.isArray(r.topics) ? (r.topics as string[]) : [],
              stargazers_count: typeof r.stargazers_count === 'number' ? r.stargazers_count : null,
              forks_count: typeof r.forks_count === 'number' ? r.forks_count : null,
              updated_at: String(r.updated_at || ''),
            };
          });
        return {
          source: 'github_live_api',
          cached: false,
          profile: {
            username: u.login || 'saurav526',
            name: u.name || 'Saurav Kumar',
            avatar_url: u.avatar_url || asset('/saurav-profile.jpg'),
            html_url: u.html_url || 'https://github.com/saurav526',
            bio:
              u.bio ||
              'AI Engineer | Data Scientist | Machine Learning Engineer | Generative AI Developer',
            location: u.location || 'Pune, Maharashtra, India',
            public_repos: typeof u.public_repos === 'number' ? u.public_repos : null,
            followers: typeof u.followers === 'number' ? u.followers : null,
            following: typeof u.following === 'number' ? u.following : null,
          },
          repositories: formatted.length > 0 ? formatted : FALLBACK_GITHUB_DATA.repositories,
          languages: Object.keys(langMap).length > 0 ? langMap : FALLBACK_GITHUB_DATA.languages,
        };
      }
    } catch {
      // Rate limited or offline
    }
  }
  return FALLBACK_GITHUB_DATA;
}

export async function updateProfileAdmin(
  updates: Partial<ProfileConfig>
): Promise<ProfileConfig> {
  const current = getLocalPortfolioState();
  const updatedProfile: ProfileConfig = { ...current.profile, ...updates };
  const nextState: PortfolioData = { ...current, profile: updatedProfile };
  saveLocalPortfolioState(nextState);

  try {
    const resp = await fetch(`${API_BASE}/admin/profile`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (resp.ok) {
      const serverProfile = (await resp.json()) as ProfileConfig;
      saveLocalPortfolioState({ ...nextState, profile: serverProfile });
      return serverProfile;
    }
  } catch {
    // Persisted in local state
  }
  return updatedProfile;
}

export async function addSkillAdmin(
  skill: Omit<Skill, 'id'>
): Promise<Skill> {
  const current = getLocalPortfolioState();
  const newSkill: Skill = {
    ...skill,
    id: Date.now(),
  };
  const nextSkills = [...current.skills, newSkill];
  saveLocalPortfolioState({
    ...current,
    skills: nextSkills,
    stats: { ...current.stats, total_skills: nextSkills.length },
  });

  try {
    const resp = await fetch(`${API_BASE}/admin/skills`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(skill),
    });
    if (resp.ok) {
      return (await resp.json()) as Skill;
    }
  } catch {
    // Persisted locally
  }
  return newSkill;
}

export async function deleteSkillAdmin(skillId: number): Promise<void> {
  const current = getLocalPortfolioState();
  const nextSkills = current.skills.filter((s) => s.id !== skillId);
  saveLocalPortfolioState({
    ...current,
    skills: nextSkills,
    stats: { ...current.stats, total_skills: nextSkills.length },
  });

  try {
    await fetch(`${API_BASE}/admin/skills/${skillId}`, { method: 'DELETE' });
  } catch {
    // Persisted locally
  }
}

export async function saveProjectAdmin(project: Project): Promise<Project> {
  const current = getLocalPortfolioState();
  const exists = current.projects.some((p) => p.id === project.id || p.slug === project.slug);
  const nextProjects = exists
    ? current.projects.map((p) =>
        p.id === project.id || p.slug === project.slug ? project : p
      )
    : [...current.projects, { ...project, id: Date.now() }];

  saveLocalPortfolioState({
    ...current,
    projects: nextProjects,
    stats: { ...current.stats, flagship_projects: nextProjects.length },
  });

  try {
    const method = exists ? 'PUT' : 'POST';
    const url = exists
      ? `${API_BASE}/admin/projects/${project.id}`
      : `${API_BASE}/admin/projects`;
    const resp = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(project),
    });
    if (resp.ok) {
      return (await resp.json()) as Project;
    }
  } catch {
    // Persisted locally
  }
  return project;
}

export async function deleteProjectAdmin(projectId: number): Promise<void> {
  const current = getLocalPortfolioState();
  const nextProjects = current.projects.filter((p) => p.id !== projectId);
  saveLocalPortfolioState({
    ...current,
    projects: nextProjects,
    stats: { ...current.stats, flagship_projects: nextProjects.length },
  });

  try {
    await fetch(`${API_BASE}/admin/projects/${projectId}`, { method: 'DELETE' });
  } catch {
    // Persisted locally
  }
}

export async function submitContactMessage(payload: {
  name: string;
  email: string;
  subject: string;
  message: string;
  honeypot?: string;
}): Promise<{
  success: boolean;
  message: string;
  delivery_mode: string;
  mailto_fallback_url: string;
}> {
  const receiver = 'sauravtiwari2712005@gmail.com';
  const mailtoUrl = `mailto:${receiver}?subject=${encodeURIComponent(
    `[Portfolio] ${payload.subject}`
  )}&body=${encodeURIComponent(
    `From: ${payload.name} (${payload.email})\n\n${payload.message}`
  )}`;

  // Save in local contacts list as well for instant visibility in Control Center
  try {
    const raw = localStorage.getItem(CONTACTS_STORAGE_KEY);
    const list: ContactSubmissionItem[] = raw ? JSON.parse(raw) : [];
    list.unshift({
      id: Date.now(),
      name: payload.name,
      email: payload.email,
      subject: payload.subject,
      message: payload.message,
      status: 'received',
      delivery_method: 'database_with_mailto_fallback',
      created_at: new Date().toISOString(),
    });
    localStorage.setItem(CONTACTS_STORAGE_KEY, JSON.stringify(list));
  } catch {
    // ignore
  }

  try {
    const resp = await fetch(`${API_BASE}/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (resp.ok) {
      return await resp.json();
    }
  } catch {
    // Fallback when running statically
  }

  return {
    success: true,
    message:
      'Your message has been logged! Because no external SMTP email server is configured in this environment, you can also click below to open your email client directly with your pre-filled message.',
    delivery_mode: 'local_with_mailto_fallback',
    mailto_fallback_url: mailtoUrl,
  };
}

export async function fetchContactSubmissions(): Promise<ContactSubmissionItem[]> {
  try {
    const resp = await fetch(`${API_BASE}/admin/contacts`);
    if (resp.ok) {
      return (await resp.json()) as ContactSubmissionItem[];
    }
  } catch {
    // fallback to localStorage
  }
  try {
    const raw = localStorage.getItem(CONTACTS_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as ContactSubmissionItem[]) : [];
  } catch {
    return [];
  }
}

export function generateLocalAssistantAnswer(
  question: string,
  portfolio: PortfolioData
): {
  reply: string;
  mode: string;
  sources: string[];
  suggested_followups: string[];
} {
  const q = question.toLowerCase().trim();
  const { profile, projects, skills, experiences, certifications } = portfolio;

  for (const p of projects) {
    const slugWords = p.slug.split('-').filter((w) => w.length > 3);
    if (slugWords.some((w) => q.includes(w)) || q.includes(p.title.toLowerCase())) {
      const features = p.key_features.slice(0, 5).map((f) => `• ${f}`).join('\n');
      let reply = `**${p.title}** (*${p.subtitle}*)\n\n**Overview:** ${p.overview}\n\n**Key Features:**\n${features}\n\n**Tech Stack:** ${p.tech_stack.join(', ')}\n\n**GitHub Repository:** ${p.github_url}`;
      if (p.disclaimer) {
        reply += `\n\n*Note: ${p.disclaimer}*`;
      }
      return {
        reply,
        mode: 'verified_local_rag',
        sources: [`Project: ${p.title}`, 'Verified Resume & GitHub'],
        suggested_followups: [
          'What are all 5 flagship projects?',
          "Tell me about Saurav's Generative AI skills",
          'How can I contact Saurav?',
        ],
      };
    }
  }

  if (
    ['project', 'built', 'work', 'system', 'portfolio', 'mcp', 'rag', 'clinical', 'opspilot', 'cyber'].some(
      (k) => q.includes(k)
    )
  ) {
    const list = projects
      .map(
        (p, idx) =>
          `${idx + 1}. **${p.title}** (${p.subtitle})\n   ${p.short_description}\n   **Stack:** ${p.tech_stack
            .slice(0, 6)
            .join(', ')}`
      )
      .join('\n\n');
    return {
      reply: `Saurav Kumar has engineered **${projects.length} flagship AI, ML, and Agentic systems**:\n\n${list}\n\nAsk me about any specific system for its architecture, workflow, and GitHub link!`,
      mode: 'verified_local_rag',
      sources: ['Projects Database', 'Verified Resume'],
      suggested_followups: [
        'Explain the Clinical Risk & Patient Outcome Intelligence System',
        'How does OpsPilot AI work?',
        'Tell me about the Autonomous Cyber Defense System',
      ],
    };
  }

  if (
    ['skill', 'stack', 'tech', 'language', 'framework', 'python', 'fastapi', 'langchain', 'langgraph', 'pytorch'].some(
      (k) => q.includes(k)
    )
  ) {
    const byCat: Record<string, string[]> = {};
    for (const s of skills) {
      if (!byCat[s.category]) byCat[s.category] = [];
      byCat[s.category].push(s.name);
    }
    const lines = Object.entries(byCat)
      .map(([cat, names]) => `• **${cat}:** ${names.join(', ')}`)
      .join('\n');
    return {
      reply: `Here is **Saurav Kumar's** verified technical skill set across **8 engineering domains**:\n\n${lines}`,
      mode: 'verified_local_rag',
      sources: ['Technical Skills Matrix', 'Verified Resume'],
      suggested_followups: [
        "Tell me about Saurav's 5 AI projects",
        "What is Saurav's internship experience?",
        'What certifications has Saurav earned?',
      ],
    };
  }

  if (['intern', 'experience', 'eduskills', 'aicte', 'siemens'].some((k) => q.includes(k))) {
    const exp = experiences[0];
    const bullets = exp.highlights.map((h) => `• ${h}`).join('\n');
    return {
      reply: `**${exp.role} — ${exp.organization}**\n*${exp.collaboration}* | **${exp.duration}** (${exp.mode})\n\n${bullets}\n\n**Skills Applied:** ${exp.skills_applied.join(', ')}`,
      mode: 'verified_local_rag',
      sources: ['Professional Experience', 'EduSkills / AICTE & Siemens'],
      suggested_followups: [
        'What projects has Saurav built?',
        "What is Saurav's educational background?",
        'How can I contact Saurav?',
      ],
    };
  }

  if (['education', 'university', 'college', 'degree', 'b.tech', 'mit adt'].some((k) => q.includes(k))) {
    return {
      reply: `**Education:**\n• **Degree:** ${profile.education_degree}\n• **Institution:** ${profile.education_institution}\n• **Duration:** ${profile.education_duration}\n• **Academic Focus:** ${profile.education_focus}`,
      mode: 'verified_local_rag',
      sources: ['Education Record', 'MIT ADT University, Pune'],
      suggested_followups: [
        'What certifications does Saurav hold?',
        "Show me Saurav's 5 AI projects",
        "Tell me about Saurav's internship",
      ],
    };
  }

  if (['certif', 'credential', 'course'].some((k) => q.includes(k))) {
    const certs = certifications.map((c) => `• **${c.title}** (*${c.domain}*)`).join('\n');
    return {
      reply: `Saurav holds **${certifications.length} verified certifications**:\n\n${certs}\n\n**Verification Link:** ${profile.certifications_drive_url}`,
      mode: 'verified_local_rag',
      sources: ['Certifications Gallery', 'Verified Resume'],
      suggested_followups: [
        "Tell me about Saurav's projects",
        'What are his Generative AI skills?',
        'How can I contact Saurav?',
      ],
    };
  }

  if (['contact', 'email', 'phone', 'hire', 'available', 'linkedin', 'github', 'location'].some((k) => q.includes(k))) {
    return {
      reply: `You can reach **Saurav Kumar** directly via:\n\n• **Availability:** ${profile.availability_status}\n• **Email:** ${profile.email}\n• **Phone:** ${profile.phone}\n• **Location:** ${profile.location}\n• **LinkedIn:** ${profile.linkedin_url}\n• **GitHub:** ${profile.github_url}`,
      mode: 'verified_local_rag',
      sources: ['Contact Information', 'Live Availability Status'],
      suggested_followups: [
        "What are Saurav's top AI projects?",
        "Summarize Saurav's technical skills",
        "Tell me about Saurav's internship",
      ],
    };
  }

  return {
    reply: `Hello! I am **Saurav AI**, the interactive portfolio assistant for **${profile.name}** (*${profile.professional_identity}*).\n\n• **Core Expertise:** Machine Learning, Deep Learning, Explainable AI (SHAP), RAG Pipelines, LangGraph Multi-Agent Systems, Model Context Protocol (MCP) Servers, and FastAPI MLOps deployment.\n• **Education:** ${profile.education_degree} (${profile.education_focus}) at ${profile.education_institution} (${profile.education_duration}).\n• **Internship:** Data Science Intern — EduSkills Foundation in collaboration with AICTE & Siemens (April 2026 – June 2026).\n• **Availability:** ${profile.availability_status}\n\nAsk me anything about Saurav's 5 flagship projects, technical stack, internship, or contact details!`,
    mode: 'verified_local_rag',
    sources: ['Verified Resume', 'Portfolio Knowledge Base'],
    suggested_followups: [
      "Tell me about Saurav's 5 flagship AI projects",
      'Explain the Clinical Risk & Patient Outcome Intelligence System',
      "What are Saurav's Generative AI and Agentic AI skills?",
      'How can I contact Saurav?',
    ],
  };
}
