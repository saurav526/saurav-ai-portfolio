@echo off
title Saurav Kumar — AI Engineer & Data Scientist Portfolio
echo ============================================================================
echo   Launching Saurav Kumar AI Portfolio in your default browser...
echo ============================================================================
start "" "%~dp0index.html"
